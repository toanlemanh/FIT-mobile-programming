import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import store from "./store";
import { Provider } from "react-redux";
import List from "./components/List";
import TaskListScreen from "./screens/TaskListScreen";
export default function App() {
  return (
    <Provider store={store}>
      <View style={styles.container}>
        <TaskListScreen/>
      </View>
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    // alignItems: "center",
    // justifyContent: "center",
  },
});
