import { View, Text, StyleSheet, TextInput, Pressable } from "react-native";
import { COLOR } from "../constants";
import List from "../components/List";
import { Ionicons } from "@expo/vector-icons";
import { useDispatch } from "react-redux";
import { useState,useEffect } from "react";
import { addTask } from "../store/taskReducer";

function TaskListScreen() {
  // const tasks = useSelector((state) => state.tasks.value);
  const dispatch = useDispatch();
  const [task, setTask] = useState("");
  console.log("tasked", task);
 
 // useEffect()
  
  function handleChangeText(text) {
    console.log(text);
    setTask(text);
  }
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>My Task Management</Text>
      </View>
      <View style={styles.wrap}>
        
        <View style={styles.user}></View>
        <View style={styles.input}>
          <TextInput
          placeholder="Adding your task"
            onChangeText={handleChangeText}
            //  onChange={(e) => console.log(e.target.value)}
          />
        </View>
        <View>
          <Pressable
            style={styles.submitButton}
            onPress={() => {
                
              dispatch(addTask(task));
            }}
          >
            <Ionicons style={styles.icon} name="send" />
          </Pressable>
        </View>
      </View>
      <View>
         <Text style={styles.titleText}>
            My List
        </Text>
      </View>
       
      <List />
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLOR.background,
    // alignItems: 'center',
  },
  header: {
    width: "100%",
    backgroundColor: COLOR.drawerBacgound,
    height: "10%",
    justifyContent: "center",
    elevation: 10,
  },
  headerText: {
    textAlign: "center",
    fontSize: 20,
    fontWeight: "bold",
    color: COLOR.background,
    textShadowRadius: 0.05,
    textShadowOffset: { width: 1, height: 1 },
    textShadowColor: "#333",
  },
  wrap: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginVertical: 50,
  },
  user: {
    height: 50,
    width: 50,
    borderRadius: 50,
    backgroundColor: COLOR.drawerBacgound,
    elevation: 10,
  },
  input: {
    height: 50,
    width: 200,
    elevation: 10,
    borderRadius: 30,
    backgroundColor: COLOR.drawerBacgound,
    justifyContent: "center",
    alignItems: "center",
  },
  submitButton: {
    height: 50,
    justifyContent: "center",
  },
  icon: {
    color: "#fff",
    fontSize: 40,
  },
  titleText:{
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 10,


   
    textShadowRadius: 0.05,
    textShadowOffset: { width: 0, height: 1 },
    textShadowColor: "#333",
  }
});

export default TaskListScreen;
