import { createSlice } from "@reduxjs/toolkit";

export const taskSlice = createSlice({
  name: "tasks",
  initialState: {
    value: [],
  },
  reducers: {
    addTask: (state, action) => {
   //   console.log(state.value);
     state.value.includes(action.payload)||state.value.push(action.payload);
    },
    completeTask: (state, action) => {
      console.log(action.payload);
      state.value = state.value.filter((task) => task !== action.payload);
    },
  },
});

export const {addTask, completeTask} = taskSlice.actions;
export default taskSlice.reducer;
