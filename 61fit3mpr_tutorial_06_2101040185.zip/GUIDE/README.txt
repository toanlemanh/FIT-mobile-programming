STEP1: install Bottom-Tab Navigator to using navagation

- npm i react-navigation/bottom-tab

STEP2: import Bottom-Tab Navigator

- import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

STEP3: using createBottomTabNavigator return Naviagtor and Screen

- const Tab = createBottomTabNavigator();

