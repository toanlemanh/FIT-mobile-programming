const users = [
    {
        name: 'anh7liem',
        content: 'Are You A Handsome Guy?',
        reply: 'Teacher',
    },
    {
        name: 'Bungay',
        content: 'Are You A Handsome Guy?',
          reply: 'give',
    },
    {
        name: 'Satij',
        content: 'Are You A Handsome Guy?',
        reply: 'me',
    },
    {
        name: 'PhoGoat',
        content: 'Are You A Handsome Guy?',
         reply: '10',
    },
    {
        name: 'Vozer500/2',
        content: 'Are You A Handsome Guy?',
        reply: 'pls',
    },
]

    

export  {users};