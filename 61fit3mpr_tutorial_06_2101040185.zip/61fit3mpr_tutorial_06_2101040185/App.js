import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import { COLOR, WINDOW_DIMENSION, SCREEN_DIMENSION } from "./constant/index.js";
import Header from "./components/Header.js";
import HomeScreen from "./screens/HomeScreen.jsx";
import BottomButtons from "./components/BottomButtons.js";
import ProfileDetailsScreen from "./screens/ProfileDetailsScreen.jsx";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import ProfileHeader from "./components/ProfileHeader.js";
import InboxScreen from "./screens/InboxScreen.jsx";
import InboxDetailsScreen from "./screens/InboxDetailsScreen.jsx";
import StoreScreen from "./screens/StoreScreen.jsx";

const BottomTab = createBottomTabNavigator();
export default function App() {
  return (
    <>
      <StatusBar style="auto" />
      <NavigationContainer>
        <BottomTab.Navigator
          initialRouteName="Home"
          tabBar={(props) => <BottomButtons {...props} />}
         
        >
          <BottomTab.Screen
            name="Home"
            component={HomeScreen}
            options={{
              headerStyle: { backgroundColor: COLOR.background },
              headerTitle: (props) => <Header {...props} />,
              headerTitleAlign: "center",
            }}
          />
          {/* <BottomTab.Screen name='Inbox' component={0}/>
             <BottomTab.Screen name='Inbox Detail' component={0}/>
             <BottomTab.Screen name='Profile' component={0}/> */}
          <BottomTab.Screen
            name="Profile Detail"
            component={ProfileDetailsScreen}
            options={{
              headerStyle: { backgroundColor: COLOR.background },
              headerTitle: (props) => <ProfileHeader {...props} />,
            }}
          />
          <BottomTab.Screen
            name="Profile"
            component={ProfileScreen}
            options={{
              headerStyle: { backgroundColor: COLOR.background },
              headerTitle: (props) => <ProfileHeader {...props} />,
            }}
          />
          <BottomTab.Screen
            name="Inbox"
            component={InboxScreen}
            options={{
              headerStyle: { backgroundColor: COLOR.background },
              headerTitle: (props) => <ProfileHeader {...props} />,
            }}
          />
          <BottomTab.Screen
            name="Inbox Detail"
            component={InboxDetailsScreen}
            options={{
              headerStyle: { backgroundColor: COLOR.background },
              headerTitle: (props) => <ProfileHeader {...props} />,
            }}
          />
        </BottomTab.Navigator>
      </NavigationContainer>
    </>

    // <View style={styles.container}>
    //   <HomeScreen/>
    //   <ProfileDetailsScreen/>
    //   <BottomButtons/>
    //   <StatusBar style="auto" />
    // </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#151C2E",
    // alignItems: 'center',
  },
});

/**
 *  video-content: 3E4659
 * background: 151C2E
 *
 *
 */
