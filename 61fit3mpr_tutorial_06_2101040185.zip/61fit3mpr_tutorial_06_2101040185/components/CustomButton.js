// following
// react
//commnent
// share
// archive
//livestream
// search
// following
// friends
// home
// store
// publish video content
// inbox
// user profile

import { View, StyleSheet, Pressable, Text, Image } from "react-native";
import React from "react";
import {
  Icon,
  COLOR,
  WINDOW_DIMENSION,
  SCREEN_DIMENSION,
} from "../constant/index.js";

export default CustomButton = ({ children }) => {
  return (
    <View>
      <Pressable style={styles.button}>
        <Text style={styles.text}>{children}</Text>
      </Pressable>
    </View>
  );
};
const styles = StyleSheet.create({
  button: {
    flex: 1,
    borderRadius: 5,
    backgroundColor: COLOR.videoContainer,
    width: WINDOW_DIMENSION.width * 0.35,
    height: WINDOW_DIMENSION.height * 0.05,
    justifyContent: "space-around",
  },
  text: {
    color: COLOR.whiteColor,
    textAlign: "center",
  },
});
