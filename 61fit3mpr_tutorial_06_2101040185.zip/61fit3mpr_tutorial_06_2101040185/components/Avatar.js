import { View, StyleSheet, Pressable, Text, Image } from "react-native";
import React from "react";
import {
  Icon,
  COLOR,
  WINDOW_DIMENSION,
  SCREEN_DIMENSION,
} from "../constant/index.js";
const avatarImage = require("../assets/pexels-alexa-popovich-14898412.jpg");
export default Avatar = () => {
  return (
    <View  style=   {styles.container}>
      <View style={styles.imageContainer}>
        <Image source={avatarImage} style={styles.image} resizeMode="stretch" />
      </View>
      <Icon style={styles.followIcon} color={COLOR.whiteColor} size={30} name={'plus-circle'}/>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    // borderRadius: 200,
    justifyContent: "center",
    alignItems: "center",

    //  width: WINDOW_DIMENSION.width*0.4,
    //  height: WINDOW_DIMENSION.height*0.2,
  },
  imageContainer: {
    borderRadius: 200,
    overflow: "hidden",
    width: 100,
    height: 100,
  },

  image: {
    flex: 1,
    width: "100%",
    height: "100%",
  },
  followIcon: {
    position: 'absolute',
    bottom: 0,
    right: 'auto',
  }
});
