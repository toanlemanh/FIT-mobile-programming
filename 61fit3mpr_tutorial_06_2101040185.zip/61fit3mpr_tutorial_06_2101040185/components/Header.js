import { View, StyleSheet, Pressable, Text } from "react-native"
import React from "react"
import { Icon, COLOR, WINDOW_DIMENSION, SCREEN_DIMENSION } from "../constant/index.js";

export default Header = (props) => {
    return(
        <View style={styles.container}>
             <Pressable>
                  <Text style={styles.text}>Friends</Text>
             </Pressable>
             <Pressable>
                  <Text style={styles.text}>Following</Text>
             </Pressable>
             <Pressable>
                  <Text style={{...styles.text, borderRightWidth: 0}}>For You</Text>
             </Pressable>
             {/* Search button */}
             <Pressable style={styles.searchIcon}>
                <Icon size={20} name={'search'} color={COLOR.whiteColor}/>
             </Pressable>
             
        </View>
    )
}

const styles = StyleSheet.create({
    container:{
        flex: 1,
        flexDirection: 'row',
        flexWrap: 'nowrap',
        paddingLeft: WINDOW_DIMENSION.width*0.1,
        // borderBottomWidth: 1,
        // borderBottomColor: COLOR.whiteColor,
        // justifyContent: 'center',
        alignItems:'center',
        width: WINDOW_DIMENSION.width,
        backgroundColor: COLOR.background,
    },
    text: {
        color: COLOR.whiteColor,
        borderRightWidth: 2,
        borderColor: COLOR.whiteColor,
        textAlign: 'center',
        paddingRight: WINDOW_DIMENSION.width*0.03,
        paddingLeft:  WINDOW_DIMENSION.width*0.03,
        fontSize: 13
    },
    searchIcon: {
        // backgroundColor: COLOR.avatar,
        position: 'relative',
        top: -WINDOW_DIMENSION.height*0.02,
        left: WINDOW_DIMENSION.width*0.1,
        
    }
})