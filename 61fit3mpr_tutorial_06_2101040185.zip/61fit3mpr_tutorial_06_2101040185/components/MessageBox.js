import React from "react";
import { View, StyleSheet, Text, ScrollView, Pressable } from "react-native";
import { COLOR, WINDOW_DIMENSION, Icon } from "../constant/index";
import Avatar from "./Avatar";
import {useNavigation} from "@react-navigation/native";


export default MessageBox = ({name, content, reply}) => {
const navigation = useNavigation();
  return (
    <View style={styles.container}>
      <View style={styles.userPlaceholder}>
      </View>
      <View style={styles.demoMessage}>
        <Pressable onPress={() => navigation.navigate('Inbox Detail', {name, content, reply})}>
             <Text style={styles.userTextStyle}>{name}</Text>
        <Text style={styles.textStyle}>{name}: {content}</Text>
        </Pressable>  
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "row",
    // justifyContent: 'space-evenly',
    paddingTop: 10,
    paddingLeft: WINDOW_DIMENSION.width*0.05,
    backgroundColor: COLOR.background,
  },
  userPlaceholder: {
    width: WINDOW_DIMENSION.width * 0.2,
    height: WINDOW_DIMENSION.height * 0.1,
    backgroundColor: COLOR.avatar,
    borderRadius: 100,
  },
  demoMessage:{
    paddingLeft: WINDOW_DIMENSION.width*0.05,
  },
  userTextStyle:{
    color: COLOR.whiteColor,
    fontSize: 15,
  },
  textStyle:{
     color: COLOR.whiteColor,
     fontSize: 12,
  }
});
