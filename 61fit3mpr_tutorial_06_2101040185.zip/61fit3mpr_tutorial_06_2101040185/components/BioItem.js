import { View, StyleSheet, Pressable, Text, Image } from "react-native";
import React from "react";
import {
  Icon,
  COLOR,
  WINDOW_DIMENSION,
  SCREEN_DIMENSION,
} from "../constant/index.js";

export default BioItem = ({children}) => {

    return (
        <View style={styles.container}>
                <Text style={styles.number}>3M</Text>
                <Text style={styles.text}>{children}</Text>
        </View>
    )
}
const styles = StyleSheet.create({
        container:{
            flexDirection: 'column',
            // backgroundColor: 'red',
            margin: 5,
        },
        number:{
            fontSize: 16,
            color: COLOR.whiteColor,
        },
        text:{
            color: COLOR.avatar,
        }
})


