import { View, StyleSheet, Pressable } from "react-native";
import { COLOR, WINDOW_DIMENSION, Icon } from "../constant";
import React from "react";


export default BottomButtons = ({navigation}) => {
  return (
    <View style={styles.container}>
      <Pressable style={styles.button} onPress={() => {navigation.navigate('Home')}}>
        <Icon name="home" size={30} color={"#fff"} />
      </Pressable>
      <Pressable style={styles.button} onPress={() => {navigation.navigate('Profile')}}>
        <Icon name="shopping-bag" size={30} color={"#fff"}  />
      </Pressable>
      <Pressable style={styles.button}>
        <Icon name="plus-square" size={30} color={"#11F2E5"} />
      </Pressable>
      <Pressable style={styles.button} onPress={() => {navigation.navigate('Inbox')}}>
        <Icon name="send" size={30} color={"#fff"} />
      </Pressable>
      <Pressable style={styles.button} onPress={() => {navigation.navigate('Profile Detail')}}>
        <Icon name="user-o" size={30} color={"#fff"} />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1 / 15,
    flexDirection: "row",
    backgroundColor: COLOR.background,
    paddingHorizontal: WINDOW_DIMENSION.width * 0.05,
    
  },
  button: {
    flex: 1,
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: COLOR.whiteColor,
    width: WINDOW_DIMENSION.width * 0.05,
    height: WINDOW_DIMENSION.height * 0.05,
    paddingVertical: WINDOW_DIMENSION.height * 0.005,
  },
});
