import { View, StyleSheet, Pressable } from "react-native"
import React from "react"


export default CustomIcon = ({children}) => {
    return(
        <View style={styles.container}>
               <Pressable>
                    {/* icon */}
               </Pressable>
        </View>
    )
}

const styles = StyleSheet.create({
    container:{
        flex: 1,
        flexDirection: 'row',
        
    }
})