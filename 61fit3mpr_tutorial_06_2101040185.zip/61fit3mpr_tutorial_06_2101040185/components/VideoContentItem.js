import { View, StyleSheet, Text } from "react-native"
import {COLOR, WINDOW_DIMENSION} from '../constant/index'

export default VideoContentItem = () => {
    return (
        <View style={styles.container}>
            
        </View>
    )
}
const styles= StyleSheet.create({
    container: {
        flex: 1,
        // width: WINDOW_DIMENSION.width*0.8,
        height: WINDOW_DIMENSION.height*0.73,
        marginTop: WINDOW_DIMENSION.height*0.02,
        borderRadius: WINDOW_DIMENSION.width*0.04,
        backgroundColor: COLOR.videoContainer,
        // overflow: 'visible',
    }
})