import { View, StyleSheet, Pressable, Text } from "react-native"
import React from "react"
import { Icon, COLOR, WINDOW_DIMENSION, SCREEN_DIMENSION } from "../constant/index.js";

export default ProfileHeader = () => {
    return(
        <View style={styles.container}>
             <Pressable>
                 <Icon size={20} name={'product-hunt'} color={COLOR.whiteColor}/>
             </Pressable>
             <Pressable flexDirection='row'>
                  <Text style={styles.text}>Toanlemanh2003</Text>
                  <Icon size={20} name={'angle-down'} color={COLOR.whiteColor}/>
             </Pressable>
             {/* Search button */}
             <Pressable >
                <Icon size={20} name={'navicon'} color={COLOR.whiteColor}/>
             </Pressable>

        </View>
    )
}

const styles = StyleSheet.create({
    container:{
        flex: 1,
        width: WINDOW_DIMENSION.width,
        flexDirection: 'row',
        paddingRight: WINDOW_DIMENSION.width*0.1,
        // borderBottomWidth: 1,
        borderBottomColor: COLOR.whiteColor,
        justifyContent: 'space-around',
        alignItems:'center',
    },
    text: {
        color: COLOR.whiteColor,
        textAlign: 'center',
        paddingRight: WINDOW_DIMENSION.width*0.03,
        paddingLeft:  WINDOW_DIMENSION.width*0.03,
        fontSize: 13
    },
    
})