import { Dimensions } from "react-native";
import  Icon  from "react-native-vector-icons/FontAwesome";
const windowDimensions = Dimensions.get("window");
const screenDimensions = Dimensions.get("screen");

const WINDOW_DIMENSION = windowDimensions;
const SCREEN_DIMENSION = screenDimensions;

const COLOR = {
  whiteColor: '#FFF',
  background: "#151C2E",
  videoContainer: "#3E4659",
  avatar: "#03C3ED",
};


export {Icon, COLOR, WINDOW_DIMENSION, SCREEN_DIMENSION };
