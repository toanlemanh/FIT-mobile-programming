import React from "react";
import { View, StyleSheet, Text, ScrollView } from "react-native";
import { COLOR, WINDOW_DIMENSION, Icon } from "../constant/index";
import VideoContentItem from "../components/VideoContentItem";
import BottomButtons from "../components/BottomButtons";
const icons = ['flag','plus-circle','heart','commenting','archive', 'share' ]
export default HomeScreen = () => {
  return (
    <View style={styles.container}>
      <View style={styles.subContainer}>
       
        <ScrollView style={styles.scrollView}>
          <VideoContentItem />
          <View style={styles.videoDescription}>
            <Text style={styles.headerText}>@toanlemanh2003</Text>
            <Text style={styles.contentText}>
              lorem ipsum Lorem ipsum dolor sit amet, consectetur adipisicing
              elit. Voluptatibus corporis est officia assumenda
            </Text>
            <Icon />
          </View>
        </ScrollView>
        <View style={styles.iconSection}  >
            {
                icons.map((icon) => {
                    return(
                        <Icon style={styles.icon} key={icon} name={icon}/>
                    )
                })
            }
        </View>
      </View>
    
    </View>
  );
};










const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: COLOR.background,
  },
  subContainer: {
    // backgroundColor: 'red',
    flex: 1,
    paddingHorizontal: WINDOW_DIMENSION.width * 0.05,
    paddingTop: WINDOW_DIMENSION.height * 0.05,
  },
  scrollView: {
    // flex: 1,
    flex: 1,
    // backgroundColor: '#fff',
    paddingHorizontal: WINDOW_DIMENSION.width * 0.05,
  },
  videoDescription: {
    paddingVertical: WINDOW_DIMENSION.height * 0.01,
  },
  headerText: {
    color: COLOR.whiteColor,
    fontSize: 16,
  },
  contentText: {
    color: COLOR.whiteColor,
    fontSize: 12,
  },
  iconSection:{
        flexDirection: 'column',
        position: 'absolute',
        right: WINDOW_DIMENSION.width*0.15,
        top: WINDOW_DIMENSION.height*0.3,
  },
  icon:{
    fontSize: 30,
    color: COLOR.whiteColor,
    marginBottom: WINDOW_DIMENSION.height*0.03,
  }
});
