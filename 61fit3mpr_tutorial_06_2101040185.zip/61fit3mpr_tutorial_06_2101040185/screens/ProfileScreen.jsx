import {COLOR} from '../constant/index.js'
import { View, StyleSheet, Text } from "react-native"
export default ProfileScreen = () => {
    return (
         <View style={styles.container}>
            <Text style={styles.text}>
                Profile
            </Text>
        </View>
    )  
}
const styles = StyleSheet.create({
    container:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: COLOR.background,
        // backgroundColor: 'red',
    },
    text:{
       color: COLOR.whiteColor,
    }
})