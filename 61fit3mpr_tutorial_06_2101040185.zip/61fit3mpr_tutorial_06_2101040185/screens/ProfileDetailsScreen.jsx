import React from "react";
import { View, StyleSheet, Text, ScrollView } from "react-native";
import { COLOR, WINDOW_DIMENSION, Icon } from "../constant/index";
import VideoContentItem from "../components/VideoContentItem";
import BottomButtons from "../components/BottomButtons";
import ProfileHeader from "../components/ProfileHeader";
import Avatar from "../components/Avatar";
import BioItem from "../components/BioItem";
import CustomButton from "../components/CustomButton";

export default ProfileDetailScreen = () => {
  return (
    <View style={styles.container}>
      <View style={styles.subContainer}>
        
        <ScrollView style={styles.scrollView}>
          <Avatar />
          <Text style={styles.username}>@toanlemanh2003</Text>
          <View style={styles.bio}>
            <BioItem>Following</BioItem>
            <BioItem>Follower</BioItem>
            <BioItem>Likes</BioItem>
          </View>
          <View style={styles.buttons}>
            <CustomButton>Edit profile</CustomButton>
            <CustomButton>Add friends</CustomButton>
          </View>
          <View style={styles.des}>
            <Text style={styles.text}>
              Lorem ipsum odio modi accusantium? Ullam assumenda maxime
              explicabo veritatis?
            </Text>
            <Icon style={{...styles.text, color: COLOR.avatar}} name='shopping-bag'/>
            <Text style={{...styles.text, color: COLOR.avatar}}>
                Your Order
            </Text>
          </View>
          <View style={styles.menu}>

          </View>
        </ScrollView>
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLOR.background,
  },
  subContainer: {
    flex: 1,
    paddingHorizontal: WINDOW_DIMENSION.width * 0.05,
    paddingTop: WINDOW_DIMENSION.height * 0.05,
    // backgroundColor: "pink",
  },
  scrollView: {
    flex: 1,
    // backgroundColor: '#fff',
    paddingHorizontal: WINDOW_DIMENSION.width * 0.05,
    paddingVertical: WINDOW_DIMENSION.height * 0.05,
  },
  username: {
    fontSize: 16,
    color: COLOR.whiteColor,
    textAlign: "center",
    marginVertical: WINDOW_DIMENSION.height * 0.02,
  },
  bio: {
    //   flex: 1,
    justifyContent: "space-between",
    padding: 10,
    flexDirection: "row",
  },
  buttons: {
    flexDirection: "row",
    justifyContent: "space-between",
    // backgroundColor: 'red'
  },
  des:{
    flex:1,
  },
  text:{
    textAlign: 'center',
    color: COLOR.whiteColor,
    fontSize: 11,
  },
  menu:{

  },
});
