import React from "react";
import { View, StyleSheet, Text, ScrollView, Pressable, TextInput } from "react-native";
import { COLOR, WINDOW_DIMENSION, Icon } from "../constant/index";

import {useNavigation} from "@react-navigation/native";

export default InboxDetailScreen = ({route}) => {
   const username = route.params.name;
   const content = route.params.content;
   const reply = route.params.reply;

    return (
        <View style={styles.container}>

        <View style={styles.friendChatBox}>
        <View style={styles.user}></View>
            <View style={styles.messageBox}>
                <Text style={styles.userTextStyle}>{username}</Text>
                <Text style={styles.messageStyle}>{content}</Text>
            </View>
        </View>

        <View style={styles.myChatBox}>
            <View style={styles.myMessageBox}>
                <Text  style={styles.userTextStyle}>{'You'}</Text>
                <Text style={styles.messageStyle}>{reply}</Text>
            </View>
            <View style={styles.me}></View>
            
        </View>
        <View style={styles.textingBox}>
            <TextInput placeholder="Send" inputMode="text"/>
        </View>
        <View style={styles.defaultMe}></View>
      </View>
    )
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor: COLOR.background,
        paddingTop: WINDOW_DIMENSION.height*0.05,
        paddingHorizontal: WINDOW_DIMENSION.width*0.05,
        
    },
    friendChatBox:{
        
        flexDirection: 'row',
        
    },
    myChatBox:{

    //    alignItems: 'flex-end',
       flexDirection: 'row',
       justifyContent: 'flex-end',
    },
    user:{
        width: WINDOW_DIMENSION.width*0.156,
        height: WINDOW_DIMENSION.height*0.08,
        borderRadius: 200,
        backgroundColor: COLOR.avatar,
    },
    me:{
        justifyContent: 'center',
        width: WINDOW_DIMENSION.width*0.156,
        height: WINDOW_DIMENSION.height*0.08,
        borderRadius: 200,
        backgroundColor: COLOR.avatar,
    },
    messageStyle:{
        color: COLOR.whiteColor,
        fontSize: 13,
    },
    userTextStyle:{
        color: COLOR.whiteColor,
        fontSize: 16,
        fontWeight: 'bold'
    },
    messageBox:{
        paddingLeft: WINDOW_DIMENSION.width*0.02,
    },
    myMessageBox:{
        paddingRight: WINDOW_DIMENSION.width*0.02,
    },
    textingBox:{
        position: 'absolute',
        bottom: WINDOW_DIMENSION.height*0.01,
        left: WINDOW_DIMENSION.width*0.05,
       width: WINDOW_DIMENSION.width*0.75,
        height: WINDOW_DIMENSION.height*0.05,
        opacity: 1,
        borderRadius: 300,
        backgroundColor: COLOR.videoContainer,
        paddingHorizontal: WINDOW_DIMENSION.width*0.05,
    },
    defaultMe:{
        position: 'absolute',
        bottom: WINDOW_DIMENSION.height*0.01,
        right: WINDOW_DIMENSION.width*0.05,
        justifyContent: 'center',
        width: WINDOW_DIMENSION.width*0.1,
        height: WINDOW_DIMENSION.height*0.05,
        borderRadius: 200,
        backgroundColor: COLOR.avatar,
    }
})


