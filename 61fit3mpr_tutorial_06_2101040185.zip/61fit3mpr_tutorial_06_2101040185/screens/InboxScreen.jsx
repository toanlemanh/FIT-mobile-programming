import React from "react";
import { View, StyleSheet, Text, ScrollView } from "react-native";
import { COLOR, WINDOW_DIMENSION, Icon } from "../constant/index";
import VideoContentItem from "../components/VideoContentItem";
import BottomButtons from "../components/BottomButtons";
import ProfileHeader from "../components/ProfileHeader";
import Avatar from "../components/Avatar";
import BioItem from "../components/BioItem";
import CustomButton from "../components/CustomButton";
import {users} from '../data/messages'
import MessageBox from "../components/MessageBox";



export default InboxScreen = () => {
    const [userState, setUserState] = React.useState(users)
    // React.useEffect(() => {
        
    // }, [])
  return (
    <View style={styles.container}>
      {userState.map((user) => {
        return (
            <MessageBox key={user} name={user.name} content={user.content} reply={user.reply} />
        )
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex:1,
    flexDirection: 'column',
  },
 
  messageBox:{
    
  }
});
