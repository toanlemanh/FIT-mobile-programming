import { useEffect, useState } from "react";
import  "./board.css"
import Row from "./Row";

let Board = ({size}) => {
    let [direction, setDirection] = useState("V");
    let [gameMatrix, setGameMatrix] = useState([]);
    let [first, setFirst] = useState(0)
    useEffect(() => {
        let matrix = Array(size).fill().map(() => Array(size).fill(null));
        setGameMatrix([...matrix]);
    }, [])
    useEffect(() => {
      if (direction=="V")  setFirst(1)
      else if (direction=="H")  setFirst(2)
    }, [direction])
   

    console.log(gameMatrix);
    let clickHandler = ([x, y]) => {
            let isChanged=false
        if(direction==="V" || direction==="" ){
            if(x<size-1)
            if(!gameMatrix[x][y] && !gameMatrix[x+1][y]){
            let matrix = gameMatrix
            direction === "V"? setDirection("H"): setDirection("V")
            matrix[x][y] = direction
            matrix[x+1][y] = direction
            setGameMatrix(matrix)
            isChanged=true

            }}
        else if(direction==="H")
            if(y<size-1)
            if(!gameMatrix[x][y] && !gameMatrix[x][y+1]){
            let matrix = gameMatrix
            direction === "V"? setDirection("H"): setDirection("V")
            matrix[x][y] = direction
            matrix[x][y+1] = direction
            setGameMatrix(matrix)
            isChanged=true
           // setcolor("bg-primary")
            }
            return {
                gameMatrix: gameMatrix,
                direction: direction,
                isChanged: isChanged
            }
        }
    const renderList = () => {
        let rows = [];
        for (let i = 0; i < size; i++) {
            rows.push(<Row key = {i} parentKey={i} size={size} 
                clickHandler={clickHandler} 
                gameMatrix={gameMatrix}
                direction={direction}
                first={first}
            
            />);
        }
        return rows;
    };

    
    return (
        <div className="table table-bordered">
            {renderList()}
        </div>
    )
}




export default Board;