import { useRef } from "react";
let Cell = ({ parentKey, childrenKey, clickHandler,gameMatrix, first,direction}) => {
    let [x,y]= [parentKey, childrenKey]
   
    let click = () => {
        let obj = clickHandler([x, y])   
      //  console.log("dir ",direction);
        if(obj.isChanged){
        console.log("you have clicked!", x, y, obj.direction, first)
         }
       else alert("Cannot check")
    }
    if (first){
        if (gameMatrix[x][y]==="V")
        return (
            <div onClick={click} className={"d-inline-block p-4 border border-dark bg-primary"}></div>
        )
        else if (gameMatrix[x][y]==="H") 
        return <div onClick={click} className={"d-inline-block p-4 border border-dark bg-danger"}></div>
        else return (
            <div onClick={click} className={"d-inline-block p-4 border border-dark "}></div>
    
        )
    }
    else return (
        <div onClick={click} className={"d-inline-block p-4 border border-dark "}></div>

    )
}
export default Cell;