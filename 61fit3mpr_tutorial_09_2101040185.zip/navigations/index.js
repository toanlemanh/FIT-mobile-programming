import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/auth";
import HomeScreen from "../screens/User/HomeScreen";
import LoginScreen from "../screens/Auth/LoginScreen";
import AuthContextProvider from "../context/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";
import AppLoading from "expo-app-loading";

// const AuthNativeStack = createNativeStackNavigator();
const NativeStack = createNativeStackNavigator();

function AuthenticatedNavigation() {
  return (
    <NativeStack.Navigator>
      <NativeStack.Screen name="HomeScreen" component={HomeScreen} />
    </NativeStack.Navigator>
  );

  // store screen after successfull authentication
}
function AuthNavigation() {
  // Authentication screen : login , signup

  return (
    <NativeStack.Navigator>
      <NativeStack.Screen name="LoginScreen" component={LoginScreen} />
    </NativeStack.Navigator>
  );
}

function RNContainer() {
  const authContext = useContext(AuthContext);
  console.log("2", authContext.isAuthenticated, authContext.token);
  return (
    <NavigationContainer>
      {authContext.isAuthenticated && <AuthenticatedNavigation />}
      {!authContext.isAuthenticated && <AuthNavigation />}
    </NavigationContainer>
  );
}
export default RNNavigation = () => {
  const [isTryingLogin, setIsTryingLogin] = useState(true);
  const authContext = useContext(AuthContext);

  useEffect(() => {
    async function fetchToken() {
      //store on the device
      const storedToken = await AsyncStorage.getItem("token");
      console.log("stored", storedToken);

      if (storedToken) {
        authContext.authenticate(storedToken);
      }
      setIsTryingLogin(false);
    }

    fetchToken();
  }, []);
  console.log(authContext.isAuthenticated, authContext.token);
  if (isTryingLogin) return <AppLoading />;
  else return <RNContainer />;
};
