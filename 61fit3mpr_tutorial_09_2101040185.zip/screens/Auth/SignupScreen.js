import { ImageBackground, Text, View, KeyboardAvoidingView } from "react-native"

export default SignupScreen = () => {
    return (
        <KeyboardAvoidingView behavior="padding" enabled>
      <ImageBackground
        style={{ height: "100%", width: wp(100) }}
        className=" items-center justify-center"
        source={require("../../assets/pikachu-wallpaper-33.webp")}
        resizeMode="cover"
      >
        
      </ImageBackground>
    </KeyboardAvoidingView>
    )
}