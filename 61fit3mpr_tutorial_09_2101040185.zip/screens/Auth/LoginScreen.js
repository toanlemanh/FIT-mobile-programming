import {
  Text,
  View,
  ImageBackground,
  KeyboardAvoidingView,
} from "react-native";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import LoginForm from "../../components/Auth/LoginForm";

export default LoginScreen = () => {
  return (
    <KeyboardAvoidingView behavior="padding" enabled>
      <ImageBackground
        style={{ height: "100%", width: wp(100) }}
        className=" items-center justify-center"
        source={require("../../assets/pikachu-wallpaper-33.webp")}
        resizeMode="cover"
      >
        <LoginForm />
      </ImageBackground>
    </KeyboardAvoidingView>
  );
};
