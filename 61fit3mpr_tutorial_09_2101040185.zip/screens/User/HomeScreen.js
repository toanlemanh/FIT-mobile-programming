import { Text, View } from "react-native"

export default HomeScreen = () => {
    return (
        <View>
            <Text>HomeScreen</Text>
        </View>
    )
}