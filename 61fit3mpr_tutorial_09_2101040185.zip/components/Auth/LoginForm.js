import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  KeyboardAvoidingView,
  Image,
} from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { useContext, useState } from "react";
import { signinWithEmail } from "../../util/firebase";
import { AuthContext } from "../../context/auth";

export default LoginForm = () => {
  const authContext = useContext(AuthContext);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function emailChangeHandler(email) {
    setEmail(email);
  }
  function passwordChangeHandler(password) {
    setPassword(password);
  }
  async function signinHandler() {
    const token = await signinWithEmail(email, password);
    authContext.authenticate(token);
     console.log('token', token);
     setEmail('');
     setPassword('');
  }

  return (
    <View
      style={{ backgroundColor: "#0BCA63" }}
      className="p-5 opacity-75 rounded-[20px]"
    >
      <View>
        <Text className="text-blue-50">Email</Text>
        <TextInput
          value={email}
          style={{ width: wp(70), height: hp(5) }}
          onChangeText={emailChangeHandler}
          inputMode="text"
          textContentType={"emailAddress"}
          className="mt-2 mb-4 rounded-[4px] bg-gray-300"
        />
        <Text className="text-blue-50">Password</Text>
        <TextInput
         value={password}
          style={{ width: wp(70), height: hp(5) }}
          onChangeText={passwordChangeHandler}
          textContentType="password"
          className="rounded-[4px] bg-gray-300 mt-2 mb-4"
        />
      </View>

      <View className="flex flex-row justify-end">
        <TouchableOpacity
          className="bg-blue-700 mr-5 justify-center rounded-[4px]"
          style={{ width: wp(20), height: hp(5) }}
          onPress={signinHandler}
        >
          <Text className="text-blue-50 text-center">Sign in</Text>
        </TouchableOpacity>
        <TouchableOpacity
          className="bg-blue-700 mr-5 justify-center rounded-[4px]"
          style={{ width: wp(20), height: hp(5) }}
        >
          <Text className="text-blue-50 text-center">Sign up</Text>
        </TouchableOpacity>
      </View>
      <Text className="text-center mt-7" style={{ fontSize: hp(1.7) }}>
        Or sign in with
      </Text>
      <View className="flex flex-row justify-around mt-2">
        <TouchableOpacity
          style={{ width: wp(30) }}
          className="justify-center items-center rounded-[10px] bg-gray-300 overflow-hidden"
        >
          <Image
            resizeMode="contain"
            style={{ width: wp(7), height: hp(5) }}
            source={require("../../assets/google.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity
          style={{ width: wp(30) }}
          className="justify-center items-center rounded-[10px] bg-gray-300"
        >
          <Image
            resizeMode="center"
            style={{ width: wp(7), height: hp(5) }}
            source={require("../../assets/facebook.png")}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};
