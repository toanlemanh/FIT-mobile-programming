export const COLOR = {
    background: '#BD8C8C',
    list: '#D9D9D9',
    drawerBacgound: '#AFA7AE',
}