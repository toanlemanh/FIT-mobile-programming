export const tasks = [
    'eat', 'sleep', 'study', 'do homework'
]