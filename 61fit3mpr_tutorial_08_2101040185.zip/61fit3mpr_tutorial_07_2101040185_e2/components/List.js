import { View, StyleSheet, Text } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLOR } from "../constants";
import CheckBox from "react-native-check-box";
import { addTask, completeTask } from "../store/taskReducer";
import { UseSelector, useDispatch, useSelector } from "react-redux";
import { useState, useEffect } from "react";
function List() {
  const tasks = useSelector((tasks) => tasks.tasks.value);
  console.log("task", tasks);
  const dispatch = useDispatch();
  const [checked, setChecked] = useState();

//   useEffect(() => {
//     // setChecked('');
//     return () =>
//       setChecked('');
//   }, [checked])

  return (
    <View style={styles.container}>
      {tasks.map((task, id) => (
        <CheckBox
          key={id}
          leftText={task}
          //   value={state}
          style={styles.checkBox}
          isChecked={checked === task+id}
          
          onClick={() => {
            setTimeout(() => {
              dispatch(completeTask(task));
            }, 1000);
            setChecked(task+id);
          }}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLOR.list,
    // flex: 1,
    padding: 20,
    // margin: 20,
    elevation: 10,
    shadowColor: "#333",
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 2,
    shadowOpacity: 0.25,
    borderRadius: 20,
  },
  checkBox: {
 //   backgroundColor: COLOR.background,
  //  padding: 10,
    marginBottom: 10,
    
  },
});
export default List;
