import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import TaskForm from "../components/TaskForm";
import { TaskContext } from "../context/TaskContext";

export default function TaskListScreen(){
    function renderTasks(tasks, deleteTaskHandler){
        return  tasks.map((task) => (
            <View style={styles.horizontal} key={task.id}>
                <Text style={styles.text}>{task.name}</Text>
                <TouchableOpacity style={styles.button} onPress={()=>{deleteTaskHandler(task.id)}}>
                    <Text style={styles.textButton}>Delete Task</Text>
                </TouchableOpacity>
            </View>))
    }


    return (
    <TaskContext.Consumer>
    {(value) => {
    const { tasks, addTask, deleteTask } = value;
    return <View style={styles.container}>
        <TaskForm></TaskForm>
        <ScrollView style={{paddingTop: 5}}>
        {renderTasks(tasks, deleteTask)}
        </ScrollView>
    </View>
    }}
</TaskContext.Consumer>)
}

const styles =StyleSheet.create({
    container: {
        paddingTop: 50,
        backgroundColor: 'beige',
        flex: 1,
    },
    horizontal: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 5,
        borderBottomWidth: 1,
        borderColor: 'cyan',
        paddingLeft: 5,
        flex: 1,
        alignItems: 'center'
    },
    button: {
        borderWidth: 1,
        borderRadius: 5,
        backgroundColor: 'cyan',
        padding: 5,
        margin: 5
    },
    text: {
        fontSize: 18,
        fontWeight: 'bold',
        color: 'brown',
        flex: 1
    },
    textButton: {
        color: 'red',
    }
})