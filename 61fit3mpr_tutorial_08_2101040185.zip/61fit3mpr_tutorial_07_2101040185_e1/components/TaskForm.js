import { useState } from "react";
import { Button, StyleSheet, Text, TextInput, View } from "react-native";
import { TaskContext } from "../context/TaskContext";

export default function TaskForm(){
    const [task, setTask] = useState({ id: "", name:"" });

    return (
    <TaskContext.Consumer>
    {(value) => {
    const { tasks, addTask, deleteTask } = value;
    return <View style={styles.container}>
        <Text> Name: </Text>
        <TextInput placeholder="Input task name"
        onChangeText={(value) => {
            setTask((prev) => ({ ...prev, name: value }))}}>
        </TextInput>
        <Button title="Submit" onPress={(id)=>{ id=Math.random(100)
            addTask({id: id, name: task.name})
        }}></Button>
    </View>
    }}
    </TaskContext.Consumer>
    )
}


const styles=StyleSheet.create({
    container: {

    }
})