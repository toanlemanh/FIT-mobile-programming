import { createContext, useState } from "react";

export const TaskContext = createContext({
    tasks: [],
    addTask: (task) => [],
    deleteTask: (id) => []
})


export default function TaskProvider({children}){
    const [tasks, setTasks] = useState([])

    function addTask(task){
        setTasks(prevTasks => [...prevTasks, {id: task.id, name: task.name}]);
    }
    
    function deleteTask(id){
        setTasks(prevTasks => prevTasks.filter((task) => task.id !== id))
    }






    const value = {
        tasks: tasks,
        addTask: addTask,
        deleteTask: deleteTask,
    }

    return <TaskContext.Provider value={value}>{children}</TaskContext.Provider>
}