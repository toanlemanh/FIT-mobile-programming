import { StatusBar } from 'expo-status-bar';
import { StyleSheet } from 'react-native';
import TaskProvider from './context/TaskContext';
// screens
import TaskListScreen from './screens/TaskListScreen';



export default function App() {
  return (
    <>
    <StatusBar style="auto" />
    <TaskProvider>
      <TaskListScreen></TaskListScreen>

    </TaskProvider>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
