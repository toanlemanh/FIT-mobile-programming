import { StatusBar } from "expo-status-bar";
import {
  StyleSheet,
  Text,
  View,
  ImageBackground,
  SafeAreaView,
} from "react-native";
import StartGameScreen from "./src/screens/StartGameScreen";
import MainGameScreen from "./src/screens/MainGameScreen";
import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import GameOver from "./src/screens/GameOver";
const bgLink = require("./src/assets/bg-start-game.png");

export default function App() {
  const [confirmedNumber, setConfirmedNumber] = React.useState();
  const [guessTimes, setGuessTimes] = React.useState(0);
  // goal: each screen is a state=> when state is change => ui is reloaded
  if (guessTimes === 0) {
    screen = <StartGameScreen chooseNumber={chooseNumber} />;
  }

  // const [screens, setScreens ] = React.useState(screen);

  function chooseNumber(number) {
    setConfirmedNumber(number);
  }
  function endGame(times) {
    console.log(times, "end game");
    setGuessTimes(times);
  }
  function restart() {
    console.log(guessTimes);
    // reset all states
    setGuessTimes(0);
    setConfirmedNumber();
  }
  if (confirmedNumber) {
    screen = <MainGameScreen answer={confirmedNumber} endGame={endGame} />; //
  }
  if (guessTimes) {
    screen = <GameOver guessTimes={guessTimes} restart={restart} />;
  }

  return (
    <LinearGradient
      style={styles.rootScreen}
      colors={["#32063c", "#72063c", "#fdb55f"]}
    >
      <ImageBackground
        source={bgLink}
        resizeMode="cover"
        style={styles.rootScreen}
        imageStyle={styles.backgroundImage}
      >
        <SafeAreaView style={styles.rootScreen}>{screen}</SafeAreaView>
      </ImageBackground>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  rootScreen: {
    flex: 1,
  },
  backgroundImage: {
    opacity: 0.15,
  },
});
