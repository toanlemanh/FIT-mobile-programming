// import { children } from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import Colors from "../constants/color.js"
const GameButton = ({ children, handlePress, disable }) => {
  function pressHandler() {
    handlePress();
  }
  return (
    <View style={styles.buttonOuterContainer}>
      <Pressable
        disabled={disable}
        
        //style={[styles.buttonInnerContainer, styles.disable]}

        style={({ pressed, disabled }) =>
          disabled ? [styles.buttonInnerContainer, styles.disable]:
          pressed
            ? [styles.buttonInnerContainer, styles.pressed]
            : styles.buttonInnerContainer
        }
        onPress={() => pressHandler()}
        android_ripple={{ color: Colors.primary600 }}
      >
        <Text style={styles.btnText}>{children}</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  buttonOuterContainer: {
    borderRadius: 28,
    margin: 4,
    overflow: "hidden",
  },
  buttonInnerContainer: {
    backgroundColor: Colors.primary500,
    // backgroundColor: "#940035",
    paddingVertical: 8,
    paddingHorizontal: 16,
    elavation: 2,
  },
  btnText: {
    color: "white",
    textAlign: "center",
  },
  pressed: {
    opacity: 0.75,
  },
  disable: {
    opacity: 0.35,
  },
});
export default GameButton;
