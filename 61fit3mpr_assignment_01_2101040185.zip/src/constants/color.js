const Colors ={
    primary500: '#940235',
    primary600: '#640233',
    accent500: "#ddb52f",

}

export default Colors;