import {
  View,
  ScrollView,
  Text,
  StyleSheet,
  ToastAndroid,
  Alert,
} from "react-native";
import MainTitle from "../components/MainTitle";
import Colors from "../constants/color";
import GameButton from "../components/GameButton";
import React from "react";

const MainGamneScreen = ({ answer, endGame }) => {
  // guess number by system until guess the answer
  // range [min, answer] , [answer, max]
  // 3 buttons: Smaller, Bingo, Higher
  // always the rest two options are wrong and alert lying
  // alert lying (compare to answer each time)
  // store the wrong answer and the number of guess

  // guess each time click
  //data
  // => guessed number by machine (state)
  // => an array (state) => add wrong guessed number to array
  const [guessedNumber, setGuessedNumber] = React.useState(
    parseInt(Math.random() * 100)
  );
  const [disableSmaller, setDisableSmasller] = React.useState(false);
  const [disableHigher, setDisableHigher] = React.useState(false);
  const [disable, setDisable] = React.useState(false);
  const [histories, setHistories] = React.useState([guessedNumber]);

  console.log(guessedNumber);

// whenever guessedNumber change, UI is updated and side effect like disabling lying buttons
  React.useEffect(() => {
    if (guessedNumber === answer) {
      // allow bingo
      setDisableHigher(true);
      setDisableSmasller(true);
      setDisable(false);
    } else if (guessedNumber < answer) {
      // allow smaller
      setDisableHigher(true);
      setDisable(true);
      setDisableSmasller(false);
    } else {
      //allow higher
      setDisableHigher(false);
      setDisable(true);
      setDisableSmasller(true);
    }
  }, [guessedNumber]);

  function generateRandomNumber(start, end) {
    let guess = parseInt(Math.floor(Math.random() * (end - start + 1) + start));
    if (guess === guessedNumber) {
      guess--;
    }
    // console.log("guess", guess);
    setHistories((prev) => [...prev, guess]);
    return guess;
  }
  function handleSmallerPress() {
    // if (answer >= guessedNumber) {
    //   console.log("lying");
    //   return;
    // }
    
    let guess = generateRandomNumber(guessedNumber, answer);
    setGuessedNumber(guess);
  }
  function handleHigherPress() {
    // This is diabled by prop disable
    //  if (answer <= guessedNumber) {
    //   console.log("lying");
    //   return;
    // }

    let guess = generateRandomNumber(answer, guessedNumber);
    setGuessedNumber(guess);
  }
  function handleBingoPress() {
    if (answer === guessedNumber) {
      console.log(answer);
      // Alert.alert('You Win!', "You've try hard", [{text:'OK',style: 'cancel'}]);
      // console.log(histories.length);
      histories.length === 1 ? endGame(1):endGame(histories.length - 1);
      
    }
  }
  // guess random each time choosing number until choosing exact number
  return (
    <ScrollView indicatorStyle="black" style={styles.screen}>
      <MainTitle>Opponent's Guess</MainTitle>
      {/* Guess */}
      <View style={styles.body}>
        <View style={styles.guessSection}>
          <Text style={styles.guessText}>{guessedNumber}</Text>
        </View>
        <View style={styles.determineSection}>
          <Text style={styles.questionText}>Higher or lower ?</Text>
          <View style={styles.buttons}>
            {/* 03 BUTTONS +  =  - pressable={pressable}
pressable={pressable}
pressable={pressable} */}
            <GameButton
              disable={disableSmaller}
              handlePress={handleSmallerPress}
            >
              Smaller
            </GameButton>
            <GameButton disable={disable} handlePress={handleBingoPress}>
              Bingo
            </GameButton>
            <GameButton disable={disableHigher} handlePress={handleHigherPress}>
              Higher
            </GameButton>
          </View>
        </View>

        <View style={styles.histories}>
          <Text style={styles.questionText}>Guess History:</Text>
          {histories.map((history, id) => (
            <View key={id} style={styles.history}>
              <Text  >
                #{id + 1}             Opponent's guess: {history}
              </Text>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
};
export default MainGamneScreen;
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    padding: 24,
    paddingTop: 40,
    // gap: 10,
  },
  body: {
    marginTop: 50,
    paddingHorizontal: 30,
  },
  guessSection: {
    width: "100%",
    height: 100,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: Colors.accent500,
    marginBottom: 50,
  },
  guessText: {
    color: Colors.accent500,
    fontSize: 24,
    fontWeight: "bold",
  },
  determineSection: {
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#63063c", //#940235
    width: "100%",
    height: 150,
    borderRadius: 10,
    justifyContent: "space-around",
  },
  questionText: {
    textAlign: "center",
    fontSize: 24,
    color: Colors.accent500,
  },
  buttons: {
    flexWrap: "wrap",
    flexDirection: "row",
  },
  histories: {
    marginTop: 50,
  },
  history: {
    borderWidth: 2,
    borderColor: Colors.primary500,
    marginTop: 20,
    paddingLeft: 20,
    // lineHeight: 40,
    // alignItems: 'center',
    justifyContent: 'center',
    height: 30,
    fontWeight: "bold",
    color: "black",
    backgroundColor: Colors.accent500,
    borderRadius: 20,
  },
});
