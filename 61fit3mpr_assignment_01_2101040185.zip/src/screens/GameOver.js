import { View, StyleSheet, Text } from "react-native";
import MainTitle from "../components/MainTitle";
import GameButton from "../components/GameButton";
import Colors from "../constants/color";
const GameOver = ({ guessTimes, restart }) => {
  function handleRestart () {
     return restart();
  }
  return (
    <View style={styles.container}>
      <MainTitle>Game Over </MainTitle>
      <View>
        <Text style={styles.descText}>You've tried {guessTimes} times !</Text>
      </View>
      <View>
        <GameButton handlePress={handleRestart}>Restart</GameButton>
        {/* how to start again that view  */}
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 40,
  },
  descText: {
     paddingVertical: 40,
     color: Colors.accent500,
  },
});
export default GameOver;
