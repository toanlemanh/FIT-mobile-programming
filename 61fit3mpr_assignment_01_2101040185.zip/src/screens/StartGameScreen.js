import { View, TextInput, StyleSheet, Alert } from "react-native";
import GameButton from "../components/GameButton";
import React from "react";
import Colors from "../constants/color";

const StartGameScreen = ({chooseNumber}) => {

const [number, setNumber ] = React.useState('');

function handleReset() {
   setNumber('');
}
function handleInput (inputNumber) {
  setNumber(inputNumber);
}
function handleConfirm() {
  //check the range of input 1-99
  const intNumber = parseInt(number);
  //isNaN => check the space case
   if ( isNaN(intNumber) || intNumber < 1 || intNumber > 99) {
       Alert.alert('Invalid number!',
       "You should choose a number in range from 1 to 99",
       [{text: "OK", style:'cancel', onPress: handleReset}]
       );
       return;
   }
  //  console.log('Valid number')
  chooseNumber(intNumber);
}


  return (
    <View style={styles.inputContainer}>
      <TextInput
        style={styles.numberInput}
        maxLength={2}
        keyboardType={"number-pad"}
        autoCapitalize="none"
        autoCorrect={false}
        onChangeText={handleInput}
        value={number}
      />
      <View style={styles.buttonContainer}>
        <View style={{flex: 1}}>
          <GameButton handlePress={handleReset}>Reset</GameButton>
        </View>
        <View style={{flex: 1}}>
          <GameButton handlePress={handleConfirm}>Confirm</GameButton>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  inputContainer: {
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 24,
    borderRadius: 8,
    //box shadow - androind
    elevation: 8,
    // for ios
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "black",
    shadowOpacity: 0.25,
    shadowRadius: 6,
    marginTop: 100,
    padding: 16,
    backgroundColor: "#63063c",
  },
  numberInput: {
    height: 50,
    width: 50,
    fontSize: 32,
    borderBottomColor: Colors.accent500,
    borderBottomWidth: 2,
    color: Colors.accent500,
    marginVertical: 8,
    fontWeight: "bold",
    textAlign: "center",
  },
  buttonContainer: {
    flexDirection: "row",
  },
});
export default StartGameScreen;
