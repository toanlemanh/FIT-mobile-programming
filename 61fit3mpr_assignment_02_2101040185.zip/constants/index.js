export const COLOR = {
    mealItemBackground: '#D1DEBB',
    mealItemText: '#F5FA10',
    header: '#CEB1B1',
    background: '#ED9D9D',
    headerTin: "#B84D4D",
    button: '#DCF4E4',
    details: '#DCF4E4',
    topic: '#FA6410',
    label: '#0F1014'

}