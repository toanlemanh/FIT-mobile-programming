import { View, Text, StyleSheet } from "react-native";
import { COLOR } from "../../constants";

export default List = ({ data }) => {
  return data.map((item, id) => {
    return (
      <View key={id} style={styles.container}>
        <Text style={styles.label} >
          {item}
        </Text>
      </View>
    );
  });
};
const styles = StyleSheet.create({
  container: {
    
  },
  label: {
    paddingHorizontal: 10,
    marginBottom: 15,
    backgroundColor: COLOR.button,
    borderRadius: 20,
    textAlign: "center",
    fontSize: 16,
    fontStyle: "italic",
    fontWeight: "bold",
    color: COLOR.label,
    lineHeight: 30,
  },
});
