import { View, StyleSheet, Text } from "react-native"

export default MealDetail = ({duration, complexity, affordability, style, textStyle}) => {
    return (
        <View style={[styles.details, style]}>
        <Text style={[styles.text, textStyle]}>{duration}m</Text>
        <Text style={[styles.text, textStyle]}>{complexity.toUpperCase()}</Text>
        <Text style={[styles.text, textStyle]}>{affordability.toUpperCase()}</Text>
      </View>
    )
}
const styles = StyleSheet.create({
    details: {
        flexDirection: "row",
        justifyContent: "center",
      },
      text: {
        margin: 8,
        fontWeight: "bold",
        color: "#fff",
      },
})