import { View, Text, StyleSheet, Dimensions, FlatList } from "react-native";
import { MEALS } from "../../data/dummy-data";
import React from "react";
import MealItem from "./MealItem";
const window = Dimensions.get("window");
const screen = Dimensions.get("screen");
import { useNavigation } from "@react-navigation/native";

function MealList({ items, dimensions, onPress }) {
  function renderMealItem(mealItemData) {
    const meal = mealItemData.item;

    return <MealItem meal={meal} dimensions={dimensions} onPress={onPress} />;
  }

  return (
    <View>
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={renderMealItem}
      ></FlatList>
    </View>
  );
}

export default MealList;
