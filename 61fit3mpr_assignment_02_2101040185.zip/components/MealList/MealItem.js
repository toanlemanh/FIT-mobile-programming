import {
  View,
  Text,
  Image,
  StyleSheet,
  Pressable,
  Platform,
} from "react-native";
import { COLOR } from "../../constants";
import MealDetail from "../MealDetail";
function MealItem({ onPress, dimensions, meal }) {
  const { id, title, duration, complexity, affordability, imageUrl } = meal;
  let { window, screen } = dimensions;
  return (
    <View
      style={[
        styles.container,
        {
          margin: window.width * 0.05,
          borderRadius: window.width * 0.03,
          // overflow: "hidden",
        },
      ]}
    >
      <Pressable
        android_ripple={{ color: "#ccc" }}
        style={({ pressed }) => [
          styles.button,
          pressed ? styles.pressed : null,
        ]}
        onPress={() => onPress(id)}
      >
        <View
        >
          <View style={{
            height: 'auto',
            overflow: "hidden",
          }}>
            <Image
              resizeMode="cover"
              style={[styles.image, { height: 180 }]}
              source={{ uri: imageUrl }}
            />
          </View>
          <Text style={styles.name}>{title}</Text>
          <MealDetail
            duration={duration}
            complexity={complexity}
            affordability={affordability}
          />
        </View>
      </Pressable>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: COLOR.mealItemBackground,
    elevation: 4,
    shadowColor: "#333",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    overflow: Platform.OS === "android" ? "hidden" : "visible",
  },
  image: {
    flex: 1,
    borderTopRightRadius: 10,
    borderTopLeftRadius: 10,
    // borderRadius: 10,
    width: "100%",
    
  },

  name: {
    textAlign: "center",
    fontWeight: "bold",
    fontSize: 20,
    marginTop: 8,
    color: COLOR.mealItemText,
    textShadowColor: "rgba(0, 0, 0, 0.75)",
    textShadowOffset: { width: -1, height: 1 },
    textShadowRadius: 10,
  },

  pressed: {
    opacity: 0.25,
  },
});
export default MealItem;
