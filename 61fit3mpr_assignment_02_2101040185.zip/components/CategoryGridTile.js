import { Pressable, View, StyleSheet, Text, Platform } from "react-native";
import React from "react";

function CategoryGridTile({ id, title, color, onPress, dimension }) {
  let window = dimension.window;

  return (
    <View
      style={[
        styles.container,
        {
          margin: window.height * 0.015,
          height: window.height * 0.2,
          width: window.width * 0.42,
         borderRadius: window.width * 0.05,
        },
      ]}
    >
      <Pressable
        android_ripple={{ color: "#ccc" }}
        style={({ pressed }) => [
          styles.button,
          pressed ? styles.pressed : null,
        ]}
        onPress={onPress}
      >
        <View style={[styles.innerContainer, { backgroundColor: color, borderRadius: window.width * 0.05, }]}>
          <Text style={styles.mealText}>{title}</Text>
        </View>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    elevation: 4,
    shadowColor: "#333",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    overflow: Platform.OS === "android" ? "hidden" : "visible",
  },
  button: {
    flex: 1,
  },
  innerContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  mealText: {
    fontWeight: "bold",
    fontSize: 18,
    // textAlign: 'center',
  },
  pressed: {
    opacity: 0.5,
  },
});
export default CategoryGridTile;
