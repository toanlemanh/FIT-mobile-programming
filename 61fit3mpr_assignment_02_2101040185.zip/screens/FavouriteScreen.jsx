import { View, StyleSheet, Text, Dimensions } from "react-native";
import { MEALS } from "../data/dummy-data";
import React from "react";
import MealList from "../components/MealList/MealList";
import { FavoriteMealsContext } from "../store/context/favorite-meals-context";

const window = Dimensions.get("window");
const screen = Dimensions.get("screen");

export default FavouriteScreen = ({ navigation }) => {
  const favoriteMealsCtx = React.useContext(FavoriteMealsContext);

  const items = MEALS.filter((meal) => {
    return favoriteMealsCtx.ids.includes(meal.id);
  });
  const [dimensions, setDimensions] = React.useState({
    window,
    screen,
  });

  function pressHandler(mealId) {
    navigation.navigate("MealDetails", mealId);
  }

  React.useEffect(() => {
    const subscription = Dimensions.addEventListener(
      "change",
      ({ window, screen }) => {
        setDimensions({ window, screen });
      }
    );
    return () => {
      subscription.remove();
    };
  });

  if (items.length === 0)
    return (
      <View style={styles.container}>
        <Text style={styles.text}>Let's explore your favorite meals!</Text>
      </View>
    );
  return (
    <MealList items={items} dimensions={dimensions} onPress={pressHandler} />
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  text: {
    color: "#351401",
    fontSize: 18,
  },
});
