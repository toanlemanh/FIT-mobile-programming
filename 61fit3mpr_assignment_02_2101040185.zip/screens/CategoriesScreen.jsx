import CategoryGridTile from "../components/CategoryGridTile";
import { CATEGORIES } from "../data/dummy-data";
import { View, ScrollView, Text, StyleSheet } from "react-native";
import { Dimensions } from "react-native";
import React from "react";
import { COLOR } from "../constants";
const window = Dimensions.get("window");
const screen = Dimensions.get("screen");

function CategoriesScreen({ navigation }) {
  const pressHanlder = (category) => {
    navigation.navigate("MealsOverview", category);
  };

  const [dimension, setDimension] = React.useState({
    window,
    screen,
  });
  React.useEffect(() => {
    const subscription = Dimensions.addEventListener(
      "change",
      ({ window, screen }) => {
        setDimension({ window, screen });
      }
    );
    return () => subscription?.remove();
  }, []);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{
        flexWrap: "wrap",
        flexDirection: "row",
        justifyContent: "space-around",
      }}
    >
      {CATEGORIES.map((category) => {
        return (
          <CategoryGridTile
            key={category.id}
            {...category}
            onPress={() => pressHanlder(category)}
            dimension={dimension}
          />
        );
      })}
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
   // backgroundColor: COLOR.background,
  },
});

export default CategoriesScreen;
