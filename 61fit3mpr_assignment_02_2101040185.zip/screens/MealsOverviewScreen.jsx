import { View, Text, StyleSheet, FlatList, Dimensions } from "react-native";
import { MEALS } from "../data/dummy-data";
import MealItem from "../components/MealList/MealItem";
import React, {useLayoutEffect} from "react";
import { COLOR } from "../constants";
import MealList from "../components/MealList/MealList";

const window = Dimensions.get('window');
const screen = Dimensions.get('screen');
function MealsOverviewScreen({ route, navigation }) {
  const { id, title, color } = route.params;
  const categoryId = id;
  const [dimensions, setDimensions]  = React.useState({
    window, screen
  })

  function pressHandler (mealId) {
      navigation.navigate("MealDetails", mealId)
  }

  React.useEffect(() => {
     const subscription = Dimensions.addEventListener('change',
     ({window, screen}) => {
          setDimensions({window, screen});
     })
     return () => {
        subscription.remove();
     }
     
  })

  //In the meal overview, prepare a list of meal. dummy-data have MEALS store each meal id and possible category id it included
  // INPUT: route.params.categoryId
  // OUTPUT: array of Meal object belong to category id

  const displayedMeals = MEALS.filter((meal) => {
    return meal.categoryIds.includes(categoryId);
  });

  // function renderMealItem(mealItemData) {
  //  const meal = mealItemData.item;
   
  //   return <MealItem meal={meal} dimensions={dimensions} onPress={pressHandler}/>;
  // }

//  displayedMeals.forEach((meal) => console.log(meal.categoryIds));
  return (
    <MealList items={displayedMeals} dimensions={dimensions} onPress={pressHandler}/>
  );
}


export default MealsOverviewScreen;
