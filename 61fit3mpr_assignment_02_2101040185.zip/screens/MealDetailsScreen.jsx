import { Text, View, StyleSheet, Image, ScrollView } from "react-native";
import { MEALS } from "../data/dummy-data";
import React, { useLayoutEffect } from "react";
import MealDetail from "../components/MealDetail";
import { COLOR } from "../constants";
import List from "../components/mealdetails/List";
import IconButton from "../components/IconButton";
import { FavoriteMealsContext } from "../store/context/favorite-meals-context";
export default MealDetailsScreen = ({ route, navigation }) => {
  const mealId = route.params;

  // get the meal which have similar id passed with route
  const displayedMeal = MEALS.find((meal) => meal.id === mealId);

  const { title, imageUrl, duration, complexity, affordability } =
    displayedMeal;

  const favoriteMealsCtx = React.useContext(FavoriteMealsContext);
   const meals = favoriteMealsCtx.ids;
  console.log(favoriteMealsCtx );

  
  const isFavoriteMeal = meals.includes(mealId);

  function toggleFavoriteMeal() {
    if (isFavoriteMeal) {
      favoriteMealsCtx.removeFavoriteMealId(mealId);
    } else {
      favoriteMealsCtx.addFavoriteMealId(mealId);
    }
  }
  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <IconButton
          icon={isFavoriteMeal ? "star" : "star-outline"}
          color={COLOR.button}
          onPress={toggleFavoriteMeal}
        />
      ),
    });
  }, [navigation, toggleFavoriteMeal]);

  return (
    <ScrollView style={styles.container}>
      <Image style={styles.image} source={{ uri: imageUrl }} />
      <Text style={styles.name}>{title} </Text>
      <MealDetail
        duration={duration}
        complexity={complexity}
        affordability={affordability}
        style={styles.detailBox}
        textStyle={styles.detailText}
      />
      <View style={styles.content}>
        <Text style={styles.topic}>Ingredients </Text>
        <List data={displayedMeal.ingredients} />
        <Text style={styles.topic}>Steps</Text>
        <List data={displayedMeal.steps} />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    width: "100%",
    height: 200,
  },
  name: {
    textAlign: "center",
    fontWeight: "bold",
    fontSize: 22,
    marginTop: 8,
    color: COLOR.mealItemText,
    textShadowColor: "rgba(0, 0, 0, 0.75)",
    textShadowOffset: { width: -1, height: 1 },
    textShadowRadius: 10,
  },
  detailBox: {
    // marginBottom: 50,
  },
  detailText: {
    margin: 2,
    fontWeight: "normal",
    fontSize: 18,
    fontStyle: "italic",
    color: COLOR.details,
  },
  topic: {
    textAlign: "center",
    color: COLOR.topic,
    fontSize: 20,
    fontWeight: "bold",
    fontStyle: "italic",
    borderBottomWidth: 1,
    borderBottomColor: COLOR.button,
    marginVertical: 30,
    paddingBottom: 10,
  },
  content: {
    paddingHorizontal: 50,
  },
});
