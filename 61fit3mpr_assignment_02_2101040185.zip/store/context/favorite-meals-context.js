// create a specific context object to manage => data and function
// it could be an object store state or data
// and relevant function to modify the state
import React, { createContext } from "react";

export const FavoriteMealsContext = createContext({
  ids: [],
  addFavoriteMealId: (id) => {},
  removeFavoriteMealId: (id) => {},
});

function FavoriteMealsContextProvider  ({ children })  {
  const [mealIds, setMealIds] = React.useState([]);

  function addFavoriteMealId(id) {
    console.log(id);
    setMealIds(
        (ids) => {
             return [...ids, id];
         }
    );
  }
  function removeFavoriteMealId(id) {
    console.log("remove")
    setMealIds((ids) => ids.filter((mealId) => mealId !== id));
  }
  const value = {
    ids: mealIds,
    addFavoriteMealId: addFavoriteMealId,
    removeFavoriteMealId: removeFavoriteMealId,
  };
  return (
    <FavoriteMealsContext.Provider value={value}>
      {children}
    </FavoriteMealsContext.Provider>
  );
};

export default FavoriteMealsContextProvider;

// create a Provider to wrap all the component working with context
