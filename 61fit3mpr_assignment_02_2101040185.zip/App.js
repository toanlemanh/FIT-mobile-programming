import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import CategoriesScreen from "./screens/CategoriesScreen";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import MealsOverviewScreen from "./screens/MealsOverviewScreen";
import MealDetailsScreen from "./screens/MealDetailsScreen";
import { COLOR } from "./constants";
import { Ionicons } from "@expo/vector-icons";
import { createDrawerNavigator } from "@react-navigation/drawer";
import FavouriteScreen from "./screens/FavouriteScreen";
import FavoriteMealsContextProvider from "./store/context/favorite-meals-context";
const NativeStack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

function DrawerNavigator() {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: COLOR.header },
        headerTintColor: COLOR.headerTin,
        sceneContainerStyle: { backgroundColor: COLOR.background },
        drawerContentStyle: { backgroundColor: COLOR.background },
        drawerInactiveTintColor: "white",
        drawerActiveTintColor: "#351401",
        drawerActiveBackgroundColor: "#e4baa1",
      }}
    >
      <Drawer.Screen
        name="MealsCategories"
        component={CategoriesScreen}
        options={{
          title: "All Categories",
          drawerIcon: ({ color, size }) => (
            <Ionicons name="list" color={color} size={size} />
          ),
        }}
      />
      <Drawer.Screen
        name="Favourites"
        component={FavouriteScreen}
        options={{
          title: "Favourite Meals",
          drawerIcon: ({ color, size }) => (
            <Ionicons name="star" color={color} size={size} />
          ),
          
        }}
      />
    </Drawer.Navigator>
  );
}
export default function App() {
  return (
    <>
      <StatusBar style="light" />
      <FavoriteMealsContextProvider>
        <NavigationContainer>
          <NativeStack.Navigator
            screenOptions={{
              headerTintColor: COLOR.headerTin,
              headerStyle: { backgroundColor: COLOR.header },
              contentStyle: {
                backgroundColor: COLOR.background,
              },
            }}
          >
            <NativeStack.Screen
              name="Drawer"
              component={DrawerNavigator}
              options={{
                headerShown: false,
              }}
            />
            <NativeStack.Screen
              name="MealsOverview"
              component={MealsOverviewScreen}
              options={({ route, navigation }) => {
                const { title } = route.params;
                console.log(title);
                return {
                  title: title,
                };
              }}
            />
            <NativeStack.Screen
              name="MealDetails"
              component={MealDetailsScreen}
            />
          </NativeStack.Navigator>
        </NavigationContainer>
      </FavoriteMealsContextProvider>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,

    alignItems: "center",
    justifyContent: "center",
  },
});
