import { View, StyleSheet, Text } from "react-native"


const EndGameScreen = () => {
      
    return (
        <View>
            <Text>{'End Game'}</Text>
        </View>
    )
}
export default EndGameScreen;
const styles = StyleSheet.create({
    container: {

    },
})