import { useEffect, useState } from "react";
import { Dimensions, Pressable, StyleSheet, Text, View } from "react-native";
import Number from "../components/Number";

import GameButton from "../components/GameButton";

import { evaluate } from "../evaluateExpression";
import CountdownCircle from "../components/CountdownCircle";

const screenWidth = Dimensions.get("window").width;

export default function GameScreen({ onEndGame }) {
  const [rndNums, setRndNums] = useState({
    num1: 0,
    num2: 0,
    num3: 0,
    num4: 0,
    num5: 0,
    num6: 0,
  });

  const [goalNumber, setGoalNumber] = useState(0);
  const [plays, setPlays] = useState(5);
  const [currentScore, setCurrentScore] = useState(0);
  const [currentOutput, setCurrentOutput] = useState(0);
  const [expressionString, setExpressionString] = useState("");
  const [disable, setDisable] = useState({
    num1: true,
    num2: true,
    num3: true,
    num4: true,
    num5: true,
    num6: true,
  });

  const [played, setPlayed] = useState(false);

  function handleCompleteTimer() {
    setPlayed(false);
    setDisable({
      num1: true,
      num2: true,
      num3: true,
      num4: true,
      num5: true,
      num6: true,
    });
  }

  //// plays = 0 la thua => end game
  const handlePress = (direction) => {
    if (plays > 0) {
      // reset all
      if (direction === "play") {
        // if (plays == 0) {
        //   //you lose
        //   alert("You lose")
        //   onEndGame(true);
        // } else
        // {
        if (!played) {
          //ktra xem con trong thoi gian countdown ko
          setPlays(plays - 1);
          setPlayed(true);
          const goal = Math.floor(Math.random() * 100);
          setGoalNumber(goal);
          setDisable({
            num1: false,
            num2: false,
            num3: false,
            num4: false,
            num5: false,
            num6: false,
          });
          setRndNums((prevState) => {
            const updatedState = Object.keys(prevState).reduce((acc, key) => {
              acc[key] = Math.floor(Math.random() * 100);
              return acc;
            }, {});
            return updatedState;
          });

          setExpressionString("");
        }

        // }
      }
      if (direction === "back") {
        setExpressionString((prev) => {
          prev = prev.substring(0, prev.length - 1);
          console.log("prev", prev);
          return prev;
          // able lai cac button
          // delete sth in the last expression
          // neu la so thi cat den dau

          //neu la dau thi cat dau do
          //    if ()
          //
        });
        // setCurrentOutput((prev))
      }
      if (direction === "clear") {
        // allow all button again
        // setPlayed(false);
        setDisable({
          num1: false,
          num2: false,
          num3: false,
          num4: false,
          num5: false,
          num6: false,
        });
        setExpressionString("");
      }
    } else {
    }
  };

  // prevent user choose 2 numbers consecutively
  //eg. choose '20' then '30' => prevent '2030'
  // catch 2 consecutive number pressed
  function isConsecutiveNumber(operator) {
    if (expressionString.length > 0) {
      let lastDigit = expressionString.charAt(expressionString.length - 1);
      let operatorInt = parseInt(operator);
      if (!isNaN(lastDigit) && !isNaN(operatorInt)) {
        //ca 2 la number
        return true; // unallow
      }
      return false;
    }
    return false;
  }
  //prevent get operator as a first argument
  // and 2 consecutive operator
  function isConsecutiveOperator(operator) {
    if (expressionString.length > 0) {
      let lastDigit = expressionString.charAt(expressionString.length - 1);
      if (operator && isNaN(operator) && isNaN(lastDigit)) {
        return true;
      }
      return false;
    }
    //
    if (isNaN(operator)) return true;
    return false;
  }

  const handleButtonPress = (direction) => {
    if (isConsecutiveNumber(direction)) {
      alert("choose an operator. Please!");
      return;
    }
    if (isConsecutiveOperator(direction)) {
      alert("choose an operand.Please!");
      return;
    }
    if (direction === rndNums.num1) {
      setDisable((prev) => {
        return { ...prev, num1: true };
      });
    }
    if (direction === rndNums.num2) {
      setDisable((prev) => {
        return { ...prev, num2: true };
      });
    }
    if (direction === rndNums.num3) {
      setDisable((prev) => {
        return { ...prev, num3: true };
      });
    }
    if (direction === rndNums.num4) {
      setDisable((prev) => {
        return { ...prev, num4: true };
      });
    }
    if (direction === rndNums.num5) {
      setDisable((prev) => {
        return { ...prev, num5: true };
      });
    }
    if (direction === rndNums.num6) {
      setDisable((prev) => {
        return { ...prev, num6: true };
      });
    }
    if (played) setExpressionString((prev) => prev + direction);
  };

  useEffect(() => {
    let result = evaluate(expressionString);
    // if (result)
    //validate
    setCurrentOutput(result);

    //else alert("stupid");
  }, [expressionString]);

  useEffect(() => {
    if (currentOutput !== 0 && currentOutput === goalNumber) {
      //  alert('You win');
      setCurrentScore((prev) => prev + 100);
      if (plays === 0) {
        onEndGame(true);
      }
    }
  }, [currentOutput]);

  //    console.log("disable", disable);

  return (
    <View style={styles.container}>
      <Pressable
        disabled={played}
        style={({ pressed, disabled }) =>
          disabled
            ? [styles.playButton, styles.disabled]
            : (pressed
            ? [styles.playButton, styles.pressed]
            : [styles.playButton, null])
        }
        onPress={handlePress.bind(this, "play")}
      >
        <Text>Play</Text>
      </Pressable>
      {played && (
        <CountdownCircle onComplete={handleCompleteTimer} played={played} />
      )}

      <View style={styles.verticalContainer}>
        <Text style={styles.text2}>Plays Remaining:</Text>
        <Text style={styles.text}>{plays}</Text>
      </View>
      {/* <Text style={styles.text}>{time}</Text> */}
      <Text style={styles.text}>{goalNumber}</Text>
      <View style={styles.numbersContainer}>
        <Number>{rndNums.num1}</Number>
        <Number>{rndNums.num2}</Number>
        <Number>{rndNums.num3}</Number>
        <Number>{rndNums.num4}</Number>
        <Number>{rndNums.num5}</Number>
        <Number>{rndNums.num6}</Number>
      </View>

      <Text>Current Score: {currentScore}</Text>
      <View style={styles.expressionContainer}>
        <Text>{expressionString}</Text>
      </View>
      <View style={styles.outputContainer}>
        <Text>Your Current Output: {currentOutput}</Text>
      </View>
      <View style={styles.horizontalContainer}>
        <View style={styles.buttonsContainer}>
          <GameButton
            disable={disable.num1}
            onPress={() => handleButtonPress(rndNums.num1)}
          >
            {rndNums.num1}
          </GameButton>
          <GameButton
            disable={disable.num2}
            onPress={() => handleButtonPress(rndNums.num2)}
          >
            {rndNums.num2}
          </GameButton>
          <GameButton
            disable={disable.num3}
            onPress={() => handleButtonPress(rndNums.num3)}
          >
            {rndNums.num3}
          </GameButton>
          <GameButton
            disable={disable.num4}
            onPress={() => handleButtonPress(rndNums.num4)}
          >
            {rndNums.num4}
          </GameButton>
          <GameButton
            disable={disable.num5}
            onPress={() => handleButtonPress(rndNums.num5)}
          >
            {rndNums.num5}
          </GameButton>
          <GameButton
            disable={disable.num6}
            onPress={() => handleButtonPress(rndNums.num6)}
          >
            {rndNums.num6}
          </GameButton>
        </View>
        <View style={styles.buttonsContainer}>
          <GameButton disable={!played} onPress={() => handleButtonPress("+")}>
            +
          </GameButton>
          <GameButton disable={!played} onPress={() => handleButtonPress("-")}>
            -
          </GameButton>
          <GameButton disable={!played} onPress={() => handleButtonPress("*")}>
            *
          </GameButton>
          <GameButton disable={!played} onPress={() => handleButtonPress("/")}>
            /
          </GameButton>
          <GameButton disable={!played} onPress={() => handleButtonPress("(")}>
            {"("}
          </GameButton>
          <GameButton disable={!played} onPress={() => handleButtonPress(")")}>
            {")"}
          </GameButton>
        </View>
      </View>
      <View style={styles.horizontalContainer}>
        <Pressable
          style={({ pressed }) =>
            pressed
              ? [styles.functionButton, styles.pressed]
              : [styles.functionButton, null]
          }
          onPress={handlePress.bind(this, "back")}
        >
          <Text>Backspace</Text>
        </Pressable>
        <Pressable
          style={({ pressed }) =>
            pressed
              ? [styles.functionButton, styles.pressed]
              : [styles.functionButton, null]
          }
          onPress={handlePress.bind(this, "clear")}
        >
          <Text>Clear</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 30,
    flex: 1,
    alignItems: "center",
    gap: 10,
    backgroundColor: "#87ceeb",
    borderRadius: 40,
    paddingTop: 20,
  },
  text: {
    fontSize: 14,
    fontWeight: "bold",
  },
  text2: {
    fontSize: 14,
  },
  verticalContainer: {
    position: "absolute",
    top: 10,
    right: 15,
    // alignItems: "center",
    // justifyContent: "center",
    flexDirection: "row",
  },
  numbersContainer: {
    // borderWidth: 1,
    // borderColor: "#fff",
    width: screenWidth,
    height: 70,
    alignItems: "center",
    justifyContent: "space-around",
    flexDirection: "row",
  },
  horizontalContainer: {
    // borderWidth: 1,
    width: screenWidth,
    alignItems: "space-around",
    justifyContent: "space-around",
    flexDirection: "row",
  },
  expressionContainer: {
    width: screenWidth - 50,
    height: 100,
    borderWidth: 1,
    borderRadius: 30,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  outputContainer: {
    borderRadius: 40,
  },
  buttonsContainer: {
    width: 102,
    height: 170,
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
  },
  playButton: {
    borderWidth: 1,
    width: 80,
    height: 50,
    borderRadius: 7,
    backgroundColor: "#90EE90",
    alignItems: "center",
    justifyContent: "center",
  },
  functionButton: {
    borderWidth: 1,
    width: 80,
    height: 50,
    borderRadius: 7,
    backgroundColor: "#ff0000",
    alignItems: "center",
    justifyContent: "center",
  },
  pressed: {
    opacity: 0.25,
  },
  disabled: {
    opacity: 0.25,
    backgroundColor: 'red',
  },
});
