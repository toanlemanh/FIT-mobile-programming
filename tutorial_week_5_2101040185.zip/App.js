import { StatusBar } from "expo-status-bar";
import {
  Platform,
  StyleSheet,
  View
} from "react-native";
import React from "react";

import GameScreen from "./screens/GameScreen";
import EndGameScreen from "./screens/EndGameScreen";

export default function App() {
   let screen = <GameScreen onEndGame={toEndGame}/>
    const [endGame, setEndGame] = React.useState(false);

    function toEndGame (bool) {
            setEndGame(bool);
    }
   
    if (endGame){
        screen = <EndGameScreen/>
    }
    else {
          screen = <GameScreen onEndGame={toEndGame}/>
    }
  
    return (
        <View style={styles.container}>
            {screen}
            <StatusBar style="auto" />
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: "center",
        justifyContent: "space-around",

        ...Platform.select({
            ios: {
                paddingTop: 20,
            },
            android: {
                paddingTop: StatusBar.currentHeight,
            },
        }),
        gap: 10,
        backgroundColor: 'beige'
    },
});
