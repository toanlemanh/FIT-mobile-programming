import { StyleSheet, Text, View } from "react-native";

export default function Number({children}) {
    return (
        <View style={styles.container}>
            <Text style={styles.text}>{children}</Text>
        </View>
    )

}

const styles = StyleSheet.create({
    container: {
        width: 50,
        height: 50,
        alignItems: 'center',
        paddingHorizontal: 10,
        borderWidth: 1,
        justifyContent: 'center',
        backgroundColor: 'white',
        borderRadius: 5,
    },
    text: {
        textAlign: 'center',
        fontWeight: 'bold'

    }
})