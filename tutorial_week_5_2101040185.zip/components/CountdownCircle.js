import { CountdownCircleTimer } from "react-native-countdown-circle-timer";
import { View, StyleSheet, Text, Alert } from "react-native";
const CountdownCircle = ({ played, onComplete }) => {
  const renderTimeHanler = ({ remainingTime }) => {
    if (remainingTime === 0) {
      return (
        <View>
          <Text>Time out !</Text>
        </View>
      );
    }
    return (
      <View>
        <View>
          <Text style={styles.text}>Remaining</Text>
        </View>
        <View>
          <Text style={{ ...styles.text, color: "red", fontWeight: "bold" }}>
            {remainingTime}
          </Text>
        </View>
        <View>
          <Text style={styles.text}>Seconds</Text>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <CountdownCircleTimer
        size={100}
        isPlaying={played}
        duration={30}
        colors={["#004777", "#F7B801", "#A30000", "#A30000"]}
        colorsTime={[30, 20, 10, 0]}
        onComplete={
          onComplete
          //Alert.alert("Success 300", "Time out", [{ style:'cancel' ,text:"OK", onPress : () => console.log('done')}] )
        }
      >
        {renderTimeHanler}
      </CountdownCircleTimer>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},
  text: {
    fontSize: 11,
    //fontFamily: 'system',
    textAlign: "center",
  },
});
export default CountdownCircle;
