import { StyleSheet, Text, Pressable, View } from "react-native";

export default function GameButton({children, onPress, disable}){
   
    return (
        <View style={styles.container}>
            <Pressable disabled={disable} 
            style={[
                styles.button,
                disable ? styles.disable : null,
              ]}
              //   SAIIIIII : style ={(pressed,disabled) => disabled ?[styles.button,styles.disable] :styles.button}
            onPress={onPress}>
                <Text style={styles.buttonText}>{children}</Text>
            </Pressable>
        </View>
    )
}
//
const styles = StyleSheet.create({
    container: {
        width: 50,
        height: 50,
        alignItems: 'center',
        marginHorizontal: 5,
    },
    button: {
        borderWidth: 1,
        width: 50,
        height: 50,
        backgroundColor: 'white',
        borderRadius: 6,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonText: {
        textAlign: 'center',
        fontWeight: 'bold'
    },
    disable:{
        opacity: 0.25,
    }
})