
import { StyleSheet, Text, View,TextInput,Image, } from 'react-native';


export default function Screen02Ver02() {
  return (
    <View style={styles.container}>
      <View style={styles.iconContainer}>
          <Image
            source={require('./assets/social.png')}
            style={styles.googleIcon}
          />
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          placeholder='Search or type web address'
        />
        <Image
          source={require('./assets/voiceIcon.png')}
          style={styles.voiceIcon}
        />
      </View>

      <ScrollView  style={styles.scrollview} horizontal={true}  >
            <View style={styles.rowContainer}>
                <View style={styles.tabContainer}>
                    <View style={styles.iconContainer}>
                    <Image
                        source={require('../assets/gmail.png')}
                        style={styles.icon}
                    />
                    
                    </View>
                    <Text style={styles.tabName}>Gmail</Text>
                </View>
                
                <View style={styles.tabContainer} >
                    <View style={styles.iconContainer}>
                    <Image
                        source={require('../assets/youtube.png')}
                        style={styles.icon}
                    />
                    </View>
                    <Text style={styles.tabName}>Youtube</Text>
                </View>
                
                <View style={styles.tabContainer}>
                    <View style={styles.iconContainer}>
                    <Image
                        source={require('../assets/google-photos.png')}
                        style={styles.icon}
                    />
                    </View>
                    <Text style={styles.tabName}>Photos</Text>
                </View>
                
                <View style={styles.tabContainer} >
                    <View style={styles.iconContainer}>
                    <Image
                        source={require('../assets/google-calendar.png')}
                        style={styles.icon}
                        />
                    </View>
                    <Text style={styles.tabName}>Calendar</Text>
                </View>
                
            </View>

            
            
            <View style={styles.rowContainer}>
                <View style={styles.tabContainer} >
                    <View style={styles.iconContainer}>
                    <Image
                        source={require('../assets/google-maps.png')}
                        style={styles.icon}
                        />
                    </View>
                    <Text style={styles.tabName}>Maps</Text>
                </View>
                <View style={styles.tabContainer} >
                    <View style={styles.iconContainer}>
                    <Image
                        source={require('../assets/google.png')}
                        style={styles.icon}
                        />
                    </View>
                    <Text style={styles.tabName}>Translate</Text>
                </View>
                <View style={styles.tabContainer} >
                    <View style={styles.iconContainer}>
                    <Image
                        source={require('../assets/google-drive.png')}
                        style={styles.icon}
                        />
                    </View>
                    <Text style={styles.tabName}>Drive</Text>
                </View>
                <View style={styles.tabContainer} >
                    <View style={styles.iconContainer}>
                    <Image
                        source={require('../assets/docs.png')}
                        style={styles.icon}
                        />
                    </View>
                    <Text style={styles.tabName}>Docs</Text>
                </View>
            </View>

        </ScrollView>
      <Text>*This is Scrollable ( Horizontally) </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent:'center',
    alignItems:'center',
  },
  iconContainer:{

  },
  searchContainer:{
    flexDirection:'row',
    justifyContent:'space-evenly',
    width:310,
    height:43,
   
    borderRadius:20,
    backgroundColor:'#CCE5FF'
  },
  googleIcon:{
    width:150,
    height:150,
    marginTop: 50
  },
  voiceIcon:{
    height:25,
    width:15,
    marginVertical:10
  },
  scrollview :{
    marginTop:13,
    width:300,
    height:108,
    
    backgroundColor:'white',
    borderRadius:15,
    elevation:14
    
},
rowContainer:{
    flexDirection:'row',
    
    marginVertical:27,
    justifyContent:'space-evenly',
    alignItems:'center'

},
iconContainer:{
    width:60,
    height:60,
    borderRadius:30,
    backgroundColor:'#C0C0C0',
    alignItems:'center',
    justifyContent:'center',
    marginHorizontal:8,
   
},
icon:{
    width:27,
    height:27,
},
tabName:{
    textAlign:'center',
    fontWeight:'300'
},
tabContainer:{
    flexDirection:"column"
}
});
