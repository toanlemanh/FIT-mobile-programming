import { StatusBar } from "expo-status-bar";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TextInput,
  Pressable,
  SafeAreaView,
  Image,
} from "react-native";
import React from "react";
import Icon from "react-native-vector-icons/FontAwesome";
const avatar = require("./assets/Toan.jpg");

let images = [];
export default function Screen01() {
  const [images, setImages] = React.useState(() => [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20])
 
  return (
    <SafeAreaView style={styles.container}>
      {/* Body content */}
      <View style={styles.bodyContent}>
        <View style={styles.header}>
          {/* Header contains back button, search bar, setting*/}
          <View style={""}>
            <Pressable>
              <Icon name={"arrow-left"} style={styles.icons} />
            </Pressable>
          </View>
          <View style={styles.searchBar}>
            <Icon
              name={"search"}
              style={{ ...styles.icons, fontSize: 13, marginRight: 10 }}
            />
            <TextInput fontSize={13} placeholder="Search here..." />
          </View>
          <View style={""}>
            <Pressable>
              <Icon name={"gear"} style={styles.icons} />
            </Pressable>
          </View>
        </View>

        {/*  */}
        <ScrollView showsVerticalScrollIndicator indicatorStyle='black'  data={images} style={styles.scrollable}>
          <View style={styles.bio}>
            {/* <Text>bio</Text> */}
            {/* <View> */}
            <View style={styles.avatar}>
              <Image
                style={{ width: "100%", height: "100%" }}
                resizeMode="cover"
                source={avatar}
              />
            </View>

            <View style={styles.user}>
              <Text style={styles.name}>Toan Le Manh</Text>
              <Text style={styles.userName}>@toanleman</Text>
              <Text style={styles.userBio}>
                Life is short. Smile when you have a teeth
              </Text>
              {/* </View> */}
            </View>
          </View>
          <View style={styles.interaction}>
            <View style={styles.follow}>
              <View>
                <Text style={styles.followNumber}>20</Text>
                <Text>Post</Text>
              </View>
              <View>
                <Text style={styles.followNumber}>378</Text>
                <Text>Followers</Text>
              </View>
              <View>
                <Text style={styles.followNumber}>99</Text>
                <Text>Following</Text>
              </View>
            </View>
            <View style={styles.buttonSection}>
              <Pressable style={{ ...styles.buttons, ...styles.editButton }}>
                <Text style={{ ...styles.buttonText, ...styles.editText }}>
                  Edit profile
                </Text>
              </Pressable>
              <Pressable style={styles.buttons}>
                <Text style={{ ...styles.buttonText, ...styles.followText }}>
                  Follow
                </Text>
              </Pressable>
            </View>
          </View>
          <View style={styles.gridLayout}  >
            {/* <Text>Grid layout</Text> */}
            {images.map((image) => (
              <View style={styles.posts} key={image} >
                <Image style={{width:'100%', height: '100%'}} resizeMode={"cover"} source={avatar} />
              </View>
            ))}
          </View>
        </ScrollView>
        {/*  */}
      </View>

      {/* Bottom bar */}
      <View style={styles.bottomBar}>
      <View style={""}>
            <Pressable>
              <Icon name={"th-large"} style={styles.icons} />
            </Pressable>
          </View>
      <View style={""}>
            <Pressable>
              <Icon name={"heart-o"} style={styles.icons} />
            </Pressable>
          </View>
      <View style={""}>
            <Pressable>
              <Icon name={"bar-chart"} style={styles.icons} />
            </Pressable>
          </View>
      <View style={""}>
            <Pressable>
              <Icon name={"user-o"} style={{...styles.icons, ...styles.pressed}} />
            </Pressable>
          </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    // paddingTop: 20,
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "beige",
    // gap: 30,
  },

  bodyContent: {
    flex: 1,
    marginTop: 20,
    width: "100%",
    paddingHorizontal: 20,
    // gap: 10,
  },

  header: {
    flex: 1 / 12,
    justifyContent: "space-between",
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "center",
    // backgroundColor: 'red',
  },
  searchBar: {
    // flex: 2,
    height: 30,
    width: "60%",
    backgroundColor: "#fff",
    elevation: 10,
    shadowOffset: {width: 0, height: 2},
    shadowColor: '#000',
    shadowOpacity: 0.25,
    borderRadius: 5,
    flexDirection: "row",
    flexWrap: "wrap",
    paddingLeft: 10,
    alignItems: "center",
  },

  avatar: {
    // backgroundColor: "red",
    width: 80,
    height: 80,
    overflow: "hidden",
    borderRadius: 100,
  },

  icons: {
    fontSize: 25,
  },

  bio: {
    flex: 1/6,
    flexDirection: "row",
    justifyContent: "space-between",
    flexWrap: "wrap",
    // backgroundColor: 'pink',
  },
  user: {
    //  backgroundColor: 'red',
    width: "60%",
    // alignContent: "space-around"
    justifyContent: "space-around",
  },
  userName: {
    fontSize: 15,
    // fontWeight: 'bold',
    color: "#4B0082",
  },
  name: {
    fontSize: 15,
    fontWeight: "bold",
  },
  followNumber: {
    fontSize: 15,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: -5,
  },
  userBio: {
    fontSize: 12,
  },
  scrollable:{
   flex: 1,
  
  //  backgroundColor: 'green',

  },

  interaction: {
    marginTop: 10,
    height: 100,
    // flex: 3/6,
    width: "100%",

    // backgroundColor: "yellow",
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    
  },
  follow: {
    width: "100%",
    height: "50%",
    // backgroundColor: 'pink',
    flexDirection: "row",
    justifyContent: "space-around",
  },
  buttonSection: {
    height: "30%",
    width: "100%",
    justifyContent: "space-between",
    flexDirection: "row",
    //  padding: 10,
    //  backgroundColor: 'white',
  },
  buttons: {
    borderWidth: 1,
    borderColor: "#4B0082",
    // backgroundColor: 'red',
    borderRadius: 10,
    height: "100%",
    width: "45%",
    alignItems: "center",
    justifyContent: "center",
  },
  editButton: {
    backgroundColor: "#4B0082",
  },
  followButton: {},
  buttonText: {
    fontSize: 10,
  },
  editText: {
    color: "white",
  },
  followText: {
    color: "#4B0082",
  },
  gridLayout: {
     width: "100%",
    //  height: 300,
    // backgroundColor: 'blue',
    justifyContent: 'space-between',
    flexDirection: 'row',
    flexWrap: 'wrap',
      
  },
  posts:{
  //  backgroundColor: "red",
    width: 100,
    height: 100,
    overflow: "hidden",
    borderRadius: 10,
    marginVertical: 5,
  
    },

  bottomBar: {
  // marginTop: 10,
  borderWidth: 0.5,
  borderColor: '#fff',
  width: '100%', 
  height: '6%',
  flexDirection: 'row',
   justifyContent: 'space-around',
  //  backgroundColor:'red',
   alignItems: 'center',
  //  padding: 10,
  },
  pressed: {
    color: '#4B0082'
  }
});
