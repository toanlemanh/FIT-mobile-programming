import { View } from "react-native";
import Screen01 from "./Screen01";
import { StrictMode } from "react";
import Screen02Ver02 from "./Screen02Ver02";

export default App = () => {

  return(
    <StrictMode>  
        {/* <Screen01/> */}
         {/* <Screen02Ver02/> */}
    </StrictMode>
    
  )
}

// import React from 'react';
// import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

// const HomeScreen = ({ navigation }) => {
//   const handleButton1Press = () => {
//     // Handle the action for Button 1
//     // For example, navigate to a different screen
//     navigation.navigate('Screen1');
//   };

//   const handleButton2Press = () => {
//     // Handle the action for Button 2
//     // For example, navigate to a different screen
//     navigation.navigate('Screen2');
//   };

//   return (
//     <View style={styles.container}>
//       <Text>Home Screen</Text>

//       <View>

//       </View>
//       <View style={styles.headerButtons}>
//         <TouchableOpacity onPress={handleButton1Press}>
//           <Text style={styles.buttonText}>Button 1</Text>
//         </TouchableOpacity>
//         <TouchableOpacity onPress={handleButton2Press}>
//           <Text style={styles.buttonText}>Button 2</Text>
//         </TouchableOpacity>
//       </View>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//     flexDirection: 'row',
//   },
//   headerButtons: {
//     flexDirection: 'row',
//     backgroundColor: 'red',
//     // position: 'absolute',
//     right: 10,
//   },
//   buttonText: {
//     marginHorizontal: 10,
//   },
// });

// export default HomeScreen;
